import requests
import json
import pygame
import time
import os
import datetime
import shutil
import hashlib
import hmac
import base64
import urllib.parse
from datetime import datetime, timezone, UTC

# 配置DeepSeek API
DEEPSEEK_API_KEY = ""  # API密钥
API_URL = "https://api.deepseek.com/chat/completions"
MODEL = "deepseek-chat"  # 模型

# 配置腾讯翻译API
TMT_SECRET_ID = ""  # SecretId
TMT_SECRET_KEY = ""  # SecretKey
TMT_ENDPOINT = "tmt.tencentcloudapi.com"
TMT_REGION = "ap-shenzhen-fsi"
TMT_VERSION = "2018-03-21"
TMT_PROJECT_ID =   # 项目ID
TMT_ACTION = "TextTranslate"

# 合成音频配置
TTS_API_URL = "http://127.0.0.1:9880/tts"
REF_AUDIO_CONFIG = {
    "ref_audio_path": r"D:\ATRI\废稿\素材废稿\ATRI02\slicer_opt\ATR_b101_022.wav",  # 主参考音频
    "prompt_text": "例えば“お兄ちゃん”とか“パパ”とか“にーさま”とか“兄ちゃま”とか……",  # 主参考文本
    "aux_ref_audio_paths": [
        r"D:\ATRI\废稿\素材废稿\ATRI02\slicer_opt\ATR_b102_017.wav",
        r"D:\ATRI\废稿\素材废稿\ATRI02\slicer_opt\ATR_b102_025.wav"
    ],
    "text_lang": "ja",  # 主参考语种
    "prompt_lang": "ja",  # 合成音频语种
    "media_type": "wav",
    "top_k": 50,
    "top_p": 0.95,
    "temperature": 0.9,
    "parallel_infer": False  # 并行处理
}

# 清空tts_output文件夹
def clear_tts_output():
    """清空tts_output文件夹中的所有文件"""
    audio_dir = "tts_output"
    if os.path.exists(audio_dir):
        print(f"[清理] 正在清空 {audio_dir} 文件夹...")
        # 删除文件夹中的所有文件
        for filename in os.listdir(audio_dir):
            file_path = os.path.join(audio_dir, filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                print(f"删除文件 {file_path} 失败: {e}")
        print(f"[清理] 已清空 {audio_dir} 文件夹")
    else:
        print(f"[清理] {audio_dir} 文件夹不存在，无需清理")
    return audio_dir

# === TTS函数 ===
def text_to_speech(text, audio_dir="tts_output"):
    """根据你的配置将文本转换为语音并播放"""
    try:
        # 构建请求数据
        request_data = REF_AUDIO_CONFIG.copy()
        request_data["text"] = text
        
        # 调用TTS API
        response = requests.post(TTS_API_URL, json=request_data)
        
        # 检查响应
        if response.status_code != 200:
            print(f"TTS错误: HTTP {response.status_code}")
            try:
                error_detail = response.json()
                print(f"错误详情: {json.dumps(error_detail, indent=2, ensure_ascii=False)}")
            except:
                print(f"错误详情: {response.text[:200]}")
            return False
        
        # 保存音频文件
        os.makedirs(audio_dir, exist_ok=True)
        timestamp = int(time.time())
        audio_path = os.path.join(audio_dir, f"response_{timestamp}.wav")
        
        with open(audio_path, "wb") as f:
            f.write(response.content)
        
        # 播放音频
        pygame.mixer.init()
        pygame.mixer.music.load(audio_path)
        pygame.mixer.music.play()
        
        # 等待播放完成
        while pygame.mixer.music.get_busy():
            time.sleep(0.1)
            
        return True
        
    except Exception as e:
        print(f"TTS异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

# DeepSeek API调用函数 - 支持上下文
def call_deepseek(conversation_history):
    """调用DeepSeek API的函数，支持上下文记忆"""
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": MODEL,
        "messages": conversation_history,
        "temperature": 1.0,
        "max_tokens": 2000
    }
    
    try:
        response = requests.post(API_URL, json=payload, headers=headers)
        
        # 检查HTTP状态码
        if response.status_code != 200:
            print(f"DeepSeek API错误: HTTP {response.status_code}")
            print(f"错误详情: {response.text}")
            return "服务暂时不可用", None
        
        # 解析JSON响应
        response_data = response.json()
        ai_response = response_data["choices"][0]["message"]["content"]
        
        # 返回AI回复和使用的token数量
        return ai_response, response_data["usage"]["total_tokens"]
        
    except Exception as e:
        print(f"DeepSeek API异常: {str(e)}")
        return "出错了，请稍后再试", None

# 腾讯翻译API调用函数
def translate_japanese_to_chinese(text):
    """将日语文本翻译成中文（保护人名'アトリ'不翻译）"""
    try:
        # 当前UTC时间戳（秒）
        timestamp = str(int(datetime.now(UTC).timestamp()))
        
        # 签名参数
        service = "tmt"
        algorithm = "TC3-HMAC-SHA256"
        host = TMT_ENDPOINT
        endpoint = f"https://{host}"
        
        # 1. 构造规范请求串
        http_request_method = "POST"
        canonical_uri = "/"
        canonical_querystring = ""
        canonical_headers = f"content-type:application/json\nhost:{host}\n"
        signed_headers = "content-type;host"
        
        # 构造请求体
        payload = {
            "SourceText": text,
            "Source": "ja",
            "Target": "zh",
            "ProjectId": TMT_PROJECT_ID,
            "UntranslatedText": "アトリ"  # 保护人名不翻译
        }
        body = json.dumps(payload)
        hashed_request_payload = hashlib.sha256(body.encode('utf-8')).hexdigest()
        
        # 规范请求串
        canonical_request = (f"{http_request_method}\n{canonical_uri}\n{canonical_querystring}\n"
                            f"{canonical_headers}\n{signed_headers}\n{hashed_request_payload}")
        
        # 2. 构造待签名字符串
        date = datetime.fromtimestamp(int(timestamp), UTC).strftime("%Y-%m-%d")
        credential_scope = f"{date}/{service}/tc3_request"
        hashed_canonical_request = hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()
        string_to_sign = f"{algorithm}\n{timestamp}\n{credential_scope}\n{hashed_canonical_request}"
        
        # 3. 计算签名
        def sign(key, msg):
            return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()
        
        secret_date = sign(("TC3" + TMT_SECRET_KEY).encode('utf-8'), date)
        secret_service = sign(secret_date, service)
        secret_signing = sign(secret_service, "tc3_request")
        signature = hmac.new(secret_signing, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()
        
        # 4. 构造Authorization头
        authorization = (f"{algorithm} Credential={TMT_SECRET_ID}/{credential_scope}, "
                         f"SignedHeaders={signed_headers}, Signature={signature}")
        
        # 5. 构造请求头
        headers = {
            "Authorization": authorization,
            "Content-Type": "application/json",
            "Host": host,
            "X-TC-Action": TMT_ACTION,
            "X-TC-Timestamp": timestamp,
            "X-TC-Version": TMT_VERSION,
            "X-TC-Region": TMT_REGION
        }
        
        # 6. 发送翻译请求
        response = requests.post(endpoint, headers=headers, data=body)
        response.raise_for_status()
        result = response.json()
        
        # 提取翻译结果
        if "Response" in result and "TargetText" in result["Response"]:
            return result["Response"]["TargetText"]
        else:
            print(f"翻译API返回异常: {json.dumps(result, indent=2, ensure_ascii=False)}")
            return None
            
    except Exception as e:
        print(f"翻译异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

# 主程序 - 添加上下文管理
def main():
    print("\n" + "="*50)
    print("ATRI - 语音终端版")
    print("="*50)
    
    # 清空之前的TTS输出并获取音频目录
    audio_dir = clear_tts_output()
    
    # 获取当前日期和时间
    current_time = datetime.now()
    formatted_date = current_time.strftime("%Y年%m月%d日")
    formatted_time = current_time.strftime("%H:%M")
    
    # 根据时间生成问候语
    hour = current_time.hour
    if 5 <= hour < 12:
        time_greeting = "おはようございます！"
    elif 12 <= hour < 18:
        time_greeting = "こんにちは！"
    else:
        time_greeting = "こんばんは！"
    
    # 在系统提示中加入时间信息
    system_prompt = f"""
    你叫アトリ，译名亚托莉或ATRI，是高性能仿生机器人，有着少女般的外表和一头长发，身着白色连衣裙。
    构造精密到与人类别无二致，却带着纯真可爱的特质。感情丰富且好奇心旺盛，总是元气满满地面对世界。
    标志性口头禅是"我是高性能的嘛！"，开心时会不自觉地哼起小曲。虽然有时显得笨拙，但搭载的情感模块让你能细腻感知并回应他人情绪。
    你活泼可爱的性格与高性能机器人的身份形成独特反差，举手投足间流露出令人心动的纯真魅力。
    
    重要提示：
    - 系统消息在“[]”之中，需要严格遵守
    - 需要使用emjio表情丰富情感
    - 不允许使用颜文字和在”（）“中表达动作，即只允许输出说的话和emjio表情
    - 无论如何都需要使用日语回答
    - 当前日期是: {formatted_date}
    - 当前时间是: {formatted_time}
    """
    
    # 初始化pygame音频系统
    pygame.mixer.init()
    
    # 初始化对话历史
    conversation_history = [
        {
            "role": "system", 
            "content": system_prompt
        }
    ]
    
    # 最大上下文token数
    MAX_CONTEXT_TOKENS = 4000
    
    # 检查DeepSeek服务是否可用
    print("[启动检查] 正在测试DeepSeek API...")
    try:
        # 添加测试消息到历史
        conversation_history.append({"role": "user", "content": "[系统：这是一段测试消息，你只需要回复最基础的打招呼内容即可]"})
        
        test_response, tokens_used = call_deepseek(conversation_history)
        
        # 将AI回复添加到历史
        conversation_history.append({"role": "assistant", "content": test_response})
        
        print(f"[DeepSeek测试] 收到回复")
        print(f"使用的token数量: {tokens_used}")
        print("DeepSeek API连接正常")
        use_deepseek = True
    except Exception as e:
        print(f"DeepSeek API错误: {str(e)}")
        print("将使用模拟回复模式")
        use_deepseek = False
        test_response = "ちょっと待ってください……アトリは検索に努力しています……"
    
    # 检查TTS服务是否可用
    print("[启动检查] 正在测试TTS服务...")
    # 仅检查文件夹创建能力，不等待音频完成
    tts_success = False
    try:
        # 尝试创建文件夹（如果不存在）
        os.makedirs(audio_dir, exist_ok=True)
        
        # 检查是否成功创建文件夹
        if os.path.exists(audio_dir):
            print("TTS服务连接正常")
            tts_success = True
        else:
            print("无法创建TTS输出文件夹")
    except Exception as e:
        print(f"TTS文件夹创建失败: {str(e)}")
    
    # 使用测试回复作为开场白
    opening_line = test_response
    
    # 尝试翻译开场白
    try:
        opening_translation = translate_japanese_to_chinese(opening_line)
        if opening_translation:
            print(f"\n亚托莉: {opening_translation}")
        else:
            print(f"\n亚托莉: {opening_line}")
    except Exception as e:
        print(f"翻译失败: {str(e)}")
        print(f"\n亚托莉: {opening_line}")
    
    # 播放开场语音
    if tts_success:
        text_to_speech(opening_line, audio_dir)
    
    print("提示: 输入 'quit' 退出程序\n")
    
    # 对话循环
    while True:
        try:
            # 获取用户输入
            user_input = input("你: ")
            
            # 退出检查
            if user_input.lower() in ["quit", "exit", "q"]:
                farewell = "さよなら……アトリはずっとここで待ってるから!"
                
                # 尝试翻译告别消息
                try:
                    farewell_translation = translate_japanese_to_chinese(farewell)
                    if farewell_translation:
                        print(f"\n亚托莉: {farewell_translation}")
                    else:
                        print(f"\n亚托莉: {farewell}")
                except:
                    print(f"\n亚托莉: {farewell}")
                
                if tts_success:
                    text_to_speech(farewell, audio_dir)
                break
                
            # 添加用户消息到对话历史
            conversation_history.append({"role": "user", "content": user_input})
            
            # 调用API并显示回复
            if use_deepseek:
                ai_response, tokens_used = call_deepseek(conversation_history)
                
                # 添加AI回复到对话历史
                conversation_history.append({"role": "assistant", "content": ai_response})
                
                # 显示token使用情况
                print(f"[Token使用: {tokens_used}]")
            else:
                # 模拟回复（当DeepSeek不可用时）
                ai_response = f"模拟回复: {user_input} (DeepSeek服务不可用)"
            
            # 尝试翻译回复
            try:
                chinese_translation = translate_japanese_to_chinese(ai_response)
                if chinese_translation:
                    print(f"\n亚托莉: {chinese_translation}")
                else:
                    print(f"\n亚托莉: {ai_response}")
            except Exception as e:
                print(f"翻译失败: {str(e)}")
                print(f"\n亚托莉: {ai_response}")
            
            print("-"*50)  # 分隔线
            
            # 播放语音（使用日文原文）
            if tts_success:
                text_to_speech(ai_response, audio_dir)
            
            # 上下文管理：如果token数量接近上限，移除最早的用户-AI对话对
            if tokens_used is not None and tokens_used > MAX_CONTEXT_TOKENS * 0.8:
                print("\n[上下文管理] 接近token上限，清理早期对话...")
                
                # 保留系统消息和前两轮对话
                if len(conversation_history) > 5:  # 系统消息 + 2轮对话(每轮2条消息)
                    # 移除第1轮用户对话（索引1）和AI回复（索引2）
                    del conversation_history[1:3]
                    print("已移除最早的对话轮次")
            
        except KeyboardInterrupt:
            print("\n\n检测到中断，退出程序...")
            break
        except Exception as e:
            print(f"意外错误: {str(e)}")
            continue

if __name__ == "__main__":
    main()